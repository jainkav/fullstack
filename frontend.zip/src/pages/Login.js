import React from 'react';

const Login = () => {
  return <div className="p-4">Login Page</div>;
};

export default Login;
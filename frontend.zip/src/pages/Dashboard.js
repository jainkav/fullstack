import React from 'react';

const Dashboard = () => {
  return <div className="p-4">Dashboard Page</div>;
};

export default Dashboard;